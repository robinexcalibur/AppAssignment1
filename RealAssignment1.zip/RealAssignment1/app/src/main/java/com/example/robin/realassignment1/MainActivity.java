package com.example.robin.realassignment1;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private int correctNumber;
    private EditText entered;
    private TextView hint;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Random randy = new Random();
        correctNumber = randy.nextInt(500);
    }

    public void submit(View view) {
        entered = findViewById(R.id.editText);
        hint = findViewById(R.id.hint);
        String hold = entered.getText().toString();
        int guess = Integer.parseInt(hold);

        if (guess > 500) {
            hint.setText("That number's out of range!");
        } else if (guess < correctNumber) {
            hint.setText("Too small!");
        } else if (guess > correctNumber) {
            hint.setText("Too high!");
        } else { // guess is correct
            hint.setText("You got it!");
        }



    }
}
